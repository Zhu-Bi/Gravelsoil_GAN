clc;
clear;

folder = 'C:\Users\ASUS\Desktop\G1\slice\';
prefix = 'p';

imageSize = 700;
numImages = 700;

volSize = [imageSize, imageSize, numImages];
volume = zeros(volSize);

for i = 1:numImages
   
    filename = sprintf('%s%s%d.tif', folder, prefix, i);
   
    slice = imread(filename);
   
    volume(:,:,i) = slice;
end

stepSize = 64; 
blockSize = [64, 64, 64]; 

numBlocks = floor((volSize - blockSize) / stepSize) + 1;

save_Folder = 'C:\Users\ASUS\Desktop\G1\volumetric_data\chair\30\train\';
save_Prefix = 'ct';

for i = 1:numBlocks(1)
    for j = 1:numBlocks(2)
        for k = 1:numBlocks(3)
           
            startIdx = (blockSize - 1) .* [i, j, k] + 1;
            endIdx = startIdx + blockSize - 1;

            
            startIdx = max(startIdx, [1, 1, 1]);
            endIdx = min(endIdx, volSize);
            
          
            block = volume(startIdx(1):endIdx(1), startIdx(2):endIdx(2), startIdx(3):endIdx(3));
            
           
            saveFilename = sprintf('%s%s_%d_%d_%d.mat', saveFolder, savePrefix, i, j, k);
            
            
            save(saveFilename, 'block');
        end
    end
end