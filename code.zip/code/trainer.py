

import torch
from torch import optim
from torch import nn
from utils import *
import os
from sklearn.manifold import MDS
from model import net_G, net_D
from sklearn.decomposition import PCA
# added
import datetime
import time
from tensorboardX import SummaryWriter
import matplotlib.pyplot as plt
import numpy as np
import params
from tqdm import tqdm
from sklearn.manifold import TSNE

def save_train_log(writer, loss_D, loss_G, itr):
    scalar_info = {}
    for key, value in loss_G.items():
        scalar_info['train_loss_G/' + key] = value

    for key, value in loss_D.items():
        scalar_info['train_loss_D/' + key] = value

    for tag, value in scalar_info.items():
        writer.add_scalar(tag, value, itr)


def save_val_log(writer, loss_D, loss_G, itr):
    scalar_info = {}
    for key, value in loss_G.items():
        scalar_info['val_loss_G/' + key] = value

    for key, value in loss_D.items():
        scalar_info['val_loss_D/' + key] = value

    for tag, value in scalar_info.items():
        writer.add_scalar(tag, value, itr)




def gradient_penalty(D, real_samples, fake_samples):


    # 在真实样本和生成样本之间进行插值
    alpha = torch.Tensor(np.random.random((real_samples.size(0), 1, 1, 1))).to(params.device)
    interpolates = (alpha * real_samples + ((1 - alpha) * fake_samples)).requires_grad_(True)

    # 计算判别器在插值样本上的输出
    d_interpolates = D(interpolates)

    # 计算插值样本的梯度
    gradients = torch.autograd.grad(outputs=d_interpolates, inputs=interpolates,
                                    grad_outputs=torch.ones(d_interpolates.size()).to(params.device),
                                    create_graph=True, retain_graph=True)[0]

    # 计算梯度的范数
    gradients_norm = torch.sqrt(torch.sum(gradients ** 2, dim=1) + 1e-12)
    gradient_penalty = ((gradients_norm - 1) ** 2).mean()

    return gradient_penalty



def trainer(args):
    # added for output dir
    save_file_path = params.output_dir + '/' + args.model_name
    print(save_file_path)  # ../outputs/dcgan
    if not os.path.exists(save_file_path):
        os.makedirs(save_file_path)

    # for using tensorboard
    if args.logs:
        model_uid = datetime.datetime.now().strftime("%d-%m-%Y-%H-%M-%S")
        # writer = SummaryWriter(params.output_dir+'/'+args.model_name+'/'+model_uid+'_'+args.logs+'/logs')
        writer = SummaryWriter(params.output_dir + '/' + args.model_name + '/' + args.logs + '/logs')

        image_saved_path = params.output_dir + '/' + args.model_name + '/' + args.logs + '/images'
        model_saved_path = params.output_dir + '/' + args.model_name + '/' + args.logs + '/models'

        if not os.path.exists(image_saved_path):
            os.makedirs(image_saved_path)
        if not os.path.exists(model_saved_path):
            os.makedirs(model_saved_path)

    # datset define
    # dsets_path = args.input_dir + args.data_dir + "train/"
    dsets_path = params.data_dir + params.model_dir + "30/train/"
    # if params.cube_len == 64:
    #     dsets_path = params.data_dir + params.model_dir + "30/train64/"

    print(dsets_path)  # ../volumetric_data/chair/30/train/

    train_dsets = ShapeNetDataset(dsets_path, args, "train")
    # val_dsets = ShapeNetDataset(dsets_path, args, "val")

    train_dset_loaders = torch.utils.data.DataLoader(train_dsets, batch_size=params.batch_size, shuffle=True,
                                                     num_workers=1)
    # val_dset_loaders = torch.utils.data.DataLoader(val_dsets, batch_size=args.batch_size, shuffle=True, num_workers=1)

    dset_len = {"train": len(train_dsets)}
    dset_loaders = {"train": train_dset_loaders}
    # print (dset_len["train"])

    # model define
    D = net_D(args)
    G = net_G(args)

    # print total number of parameters in a model
    # x = sum(p.numel() for p in G.parameters() if p.requires_grad)
    # print (x)
    # x = sum(p.numel() for p in D.parameters() if p.requires_grad)
    # print (x)

    D_solver = optim.Adam(D.parameters(), lr=params.d_lr, betas=params.beta)
    # D_solver = optim.SGD(D.parameters(), lr=args.d_lr, momentum=0.9)
    G_solver = optim.Adam(G.parameters(), lr=params.g_lr, betas=params.beta)

    D.to(params.device)
    G.to(params.device)



    itr_val = -1
    itr_train = -1

    losses_G = []
    losses_D = []
    for epoch in range(params.epochs):
        start = time.time()

        for phase in ['train']:
            if phase == 'train':
                D.train()
                G.train()
            else:
                D.eval()
                G.eval()

            running_loss_G = 0.0
            running_loss_D = 0.0
            running_loss_adv_G = 0.0
            running_loss_gp = 0.0
            for i, X in enumerate(tqdm(dset_loaders[phase])):
                itr_train += 1
                X = X.to(params.device)
                batch = X.size()[0]
                Z = generateZ(args, batch)

                # 计算判别器的损失和梯度惩罚
                d_real = D(X)
                fake = G(Z)


                a=9
                d_fake = D(fake)
                d_loss = d_fake.mean() - d_real.mean()+ a*gradient_penalty(D, X, fake)

                D.zero_grad()
                d_loss.backward()
                D_solver.step()




                # 计算生成器的损失
                if itr_train % params.n_critic == 0:
                    Z = generateZ(args, batch)
                    fake = G(Z)
                    g_loss = -D(fake).mean()

                    G.zero_grad()
                    g_loss.backward()
                    G_solver.step()

                    running_loss_G += g_loss.item() * X.size(0)
                    running_loss_D += d_loss.item() * X.size(0)



                if args.logs and itr_train % 1 == 0:
                    loss_G = {'adv_loss_G': g_loss}
                    loss_D = {'adv_loss_D': d_loss}
                    save_train_log(writer, loss_D, loss_G, itr_train)

                losses_G.append(g_loss.item())
                losses_D.append(d_loss.item())

            epoch_loss_G = running_loss_G / dset_len[phase]
            epoch_loss_D = running_loss_D / dset_len[phase]
            end = time.time()
            epoch_time = end - start

            print('Epochs-{} ({}) , D Loss: {:.4}, G Loss: {:.4}'.format(epoch, phase, epoch_loss_D, epoch_loss_G))
            print('Elapsed Time: {:.4} min'.format(epoch_time / 60.0))
            if (epoch + 1) % 1 == 0:
                X_cpu = X.cpu().detach().numpy()

                fake_cpu = fake.cpu().detach().numpy()

                # 将X和fake展平为二维数组
                X_flat = X_cpu.reshape(X.shape[0], -1)
                combined_flat_image1 = X_flat.T

                fake_flat = fake_cpu.reshape(fake.shape[0], -1)
                combined_flat_image2 = fake_flat.T

                # 选择你感兴趣的列进行降维和可视化
                columns_of_interest1 = [0, 2]  # 假设你对第一列和第三列感兴趣
                selected1 = combined_flat_image1[:, columns_of_interest1]
                rows_of_interest = 1000 # 假设你对前100行感兴趣
                selected_data1 = selected1[:rows_of_interest, :]
                tsne = TSNE(n_components=2)
                embedded_samples1 = tsne.fit_transform(selected_data1)

                '''columns_of_interest2 = [0, 2]  
                selected2 = combined_flat_image2[:, columns_of_interest2]
                rows_of_interest = 1000  
                selected_data2 = selected2[:rows_of_interest, :]
                tsne = TSNE(n_components=2)
                embedded_samples2 = tsne.fit_transform(selected_data2)'''

                '''columns_of_interest3 = [0, 2]  
                selected3 = combined_flat_image2[:, columns_of_interest3]'''
                rows_of_interest = 1000
                selected_data3 = combined_flat_image2[:rows_of_interest, :]

                try:
                    mds = MDS(n_components=2)
                    embedded_samples3 = mds.fit_transform(selected_data3)
                except Exception as e:
                    print("无法计算MDS:", e)




                #print(reduced_samples2)
                #pca = PCA(n_components=2)
                #embedded_samples1 = pca.fit_transform(combined_flat_image1)


                #pca = PCA(n_components=2)
                #embedded_samples2 = pca.fit_transform(combined_flat_image2)


                #mds_X = MDS(n_components=2)
                #proj_X = mds_X.fit_transform(combined_flat_image1)

                #mds_fake = MDS(n_components=2)
                #proj_fake = mds_fake.fit_transform(combined_flat_image2)


                np.savetxt('/mnt/PyCharm_Project_1/2/original_dim_reduced_data_{}.txt'.format(epoch), embedded_samples1)
                np.savetxt('/mnt/PyCharm_Project_1/2/generated_dim_reduced_data_{}.txt'.format(epoch), embedded_samples3)

                # 可视化


                plt.scatter(embedded_samples1[:, 0], embedded_samples1[:, 1], c='blue', label='original_data')
                plt.scatter(embedded_samples3[:, 0], embedded_samples3[:, 1], c='red', label='generated_data')
                plt.show()
                plt.legend()
                plt.show()
                plt.savefig('/mnt/PyCharm_Project_1/2/MDS_{}.png'.format(epoch))
                plt.close()
            if (epoch + 1) % 10 == 0:
                print('model_saved, images_saved...')

                G_file_name = model_saved_path + '/G_' + str(epoch + 1) + '.pth'
                D_file_name = model_saved_path + '/D_' + str(epoch + 1) + '.pth'

                torch.save(G.state_dict(), G_file_name)
                torch.save(D.state_dict(), D_file_name)

                samples = fake.cpu().data[:8].squeeze().numpy()


                SavePloat_Voxels(samples, image_saved_path, epoch)


            if (epoch + 1) % 1 == 0:
                plt.figure()
                plt.plot(losses_G, label='Generator Loss')
                plt.plot(losses_D, label='Discriminator Loss')
                plt.xlabel('Iterations')
                plt.ylabel('Loss')
                plt.title('Loss Curves')
                plt.legend()
                plt.savefig('/mnt/PyCharm_Project_1/1/loss_curve_epoch_{}.png'.format(epoch))
                plt.close()
                '''X_cpu = X.cpu().detach().numpy()
                fake_cpu = fake.cpu().detach().numpy()
                
                X_flat =X_cpu.reshape(X.shape[0], -1)
                fake_flat = fake_cpu.reshape(fake.shape[0], -1)

               
                mds_X = MDS(n_components=2)
                proj_X = mds_X.fit_transform(X_flat)

                
                mds_fake = MDS(n_components=2)
                proj_fake = mds_fake.fit_transform(fake_flat)

                
                np.savetxt('/mnt/PyCharm_Project_1/2/original_dim_reduced_data_{}.txt'.format(epoch), proj_X)
                np.savetxt('/mnt/PyCharm_Project_1/2/generated_dim_reduced_data_{}.txt'.format(epoch), proj_fake)

               
                fig, ax = plt.subplots()
                ax.scatter(proj_X[:, 0], proj_X[:, 1], color='blue', label='original data')
                ax.scatter(proj_fake[:, 0], proj_fake[:, 1], color='red', label='generated data')
                ax.set_title('MDS Projection of Original and Generated Data')
                ax.legend()
                plt.show()
                plt.savefig('/mnt/PyCharm_Project_1/2/MDS_{}.png'.format(epoch))
                plt.close()'''



                with open('/mnt/PyCharm_Project_1/1/losses_epoch_{}.txt'.format(epoch), 'w') as f:
                    for i in range(len(losses_G)):
                        f.write(
                            'Iteration {}: Generator Loss = {}, Discriminator Loss = {}\n'.format(i, losses_G[i],
                                                                                                    losses_D[i]))


