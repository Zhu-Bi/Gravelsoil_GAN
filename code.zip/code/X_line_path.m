clc;
clear;

data = load('C:\Users\ASUS\Desktop\G1\G1_data_mat\O11.mat');
image= data.block;
%image= data.block;

thresh = graythresh(image);
image_data = imbinarize(image, thresh);

one_lengths = [];
cur_length = 1; 
size_x = size(image_data);

for k = 1:size_x(3) 
    cur_slice = image_data(:, :, k);
    
    for i = 1:size_x(1)
        cur_length = 1;  
        n = 0; 
        
        for j = 1:size_x(2)
            if cur_slice(i, j) == 1
                cur_length = cur_length + 1;
                if j == size_x(2)
                    n = n + 1;
                    one_lengths(i, n, k) = cur_length;
                end
            else 
                if cur_length > 0
                    n = n + 1;
                    one_lengths(i, n, k) = cur_length;
                    cur_length = 0;
                end
            end
        end
    end 
    
    if cur_length > 0
        one_lengths(i, n, k) = cur_length;
    end
end 


a = tabulate(one_lengths(:));

b = a(:, 1);
c = a(:, 2);

 L0=sum(image_data(:)==1);
 L00=L0/(64*64*64);

for i = 1:64
    b_i2 = b - (i - 1);
    b_i2(b_i2 < 0) = 0;
    img_size2 = size(image_data);
    L(i ) = sum(b_i2 .* c) / (64*64*64);
end
Lr=L;
Lr(1)=L00;
T = table(Lr');
r = 1:64;
figure
plot(r, Lr, '--om')
xlabel('r(pixels)')
ylabel('L(r)')
title('L(r)probability curve')



