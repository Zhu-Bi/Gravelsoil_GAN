clc;
clear;

folder_path = 'C:\Users\ASUS\Desktop\G3\G3_image\14\';

data = load('C:\Users\ASUS\Desktop\G3\G3_data_mat\denoised_14.mat');
array_3d = data.denoised_image;
%array_3d = data.block ;
% figure
% volshow(array_3d);

for i = 1:size(array_3d, 3)

    plane = array_3d(:, :, i);
    
   
    plane = mat2gray(plane);
    plane = uint8(plane * 255);
    
    
    image_path = fullfile(folder_path, sprintf('image_%d.tif', i));
    imwrite(plane, image_path);
end

