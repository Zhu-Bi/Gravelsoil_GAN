clc;
clear;

tic;

data = load('C:\Users\ASUS\Desktop\G1\G1_data_mat\2.mat'); 

img = data.block;
%img = data.block;

thresh = graythresh(img);
binaryImage = imbinarize(img, thresh);

image = logical(binaryImage);
binaryMatrix1 = ~logical(binaryImage);

N = size(image, 1);


distances = 0:64; 

S2_r = zeros(size(distances));

for index = 1:length(distances)
    r = distances(index);
    
    
    count = 0;
    sum_product = 0;
    for x = 1:N
        for y = 1:N
            for z = 1:N
                if image(x, y, z) ==0
                    Z_x = 0;
                else
                    Z_x = 1;
                end

                
                if (x+r <= N)
                    if image(x+r, y, z) == 0
                        Z_xr = 0;
                    else
                        Z_xr = 1;
                    end

                    sum_product = sum_product + Z_x * Z_xr;
                    count = count + 1;
                end
            end
        end
    end

   
    S2_r(index) = sum_product / count;
end
T = table(S2_r');

nonZeroIndices = S2_r ~= 0;

nonZeroElements = S2_r(nonZeroIndices);

T1 = table(nonZeroElements');

plot(distances, S2_r,'--om');
xlabel('r');
ylabel('S2(r)');
title('S2(r)probability curve');
